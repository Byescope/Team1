#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dictionary.h"
#include <stdbool.h>
#define CONTACT_SIZE	50